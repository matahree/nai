package com.company;


import javax.xml.crypto.Data;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

public class Main
{
    private static File trainSetFile = new File("iris.data");
    private static File testSetFile = new File("iris.test.data");
    private static int k = 5;

    private static List<DataObject> objectList = new ArrayList<>();
    private static int correctClassification = 0;
    private static int totalClassifications = 0;

    public static void main(String[] args)
    {
        CheckInputArguments(args);

        try(Stream linesStream = Files.lines(trainSetFile.toPath())) //Reading the train set data and adding irises to the list
        {
            linesStream.forEach(line -> {
                String[] linesParts = line.toString().split(",");
                List<Float> temp = new ArrayList<>();
                for (int i = 0; i < linesParts.length-1; i++)
                {
                    temp.add(Float.parseFloat(linesParts[i]));
                }
                Vector4 data = new Vector4(temp);
                objectList.add(new DataObject(data, linesParts[linesParts.length-1]));
            });
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        try(Stream linesStream = Files.lines(testSetFile.toPath())) //Reading the test set data and, calculating distances to the irises from the train set and classifying them
        {
            linesStream.forEach(line -> {
                String[] linesParts = line.toString().split(",");
                List<Float> temp = new ArrayList<>();
                for (int i = 0; i < linesParts.length-1; i++)
                {
                    temp.add(Float.parseFloat(linesParts[i]));
                }
                Vector4 data = new Vector4(temp);
                DataObject obj = new DataObject(data, objectList);
                obj.ClassifyObject(k);
                System.out.println(obj);

                totalClassifications++;
                if(obj.GetType().equals(linesParts[linesParts.length-1]))
                {
                    correctClassification++;
                }                                                              // counter for correct classifications and total classifications
            });
            System.out.println("Accuracy : " + (float)correctClassification/(float)totalClassifications);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        Scanner scanner = new Scanner(System.in);
        String command;
        do
        {
            System.out.println();
            System.out.println("Enter values for new Iris (x,y,z,t)");
            command = scanner.next();
            String[] linesParts = command.split(",");
            List<Float> temp = new ArrayList<>();
            for (int i = 0; i < linesParts.length; i++)
            {
                temp.add(Float.parseFloat(linesParts[i]));
            }
            Vector4 data = new Vector4(temp);
            DataObject iris = new DataObject(data, objectList);
            iris.ClassifyObject(k);
            System.out.println(iris);
        }
        while(true);
    }

    private static void CheckInputArguments(String[] args)
    {
        if(args.length > 0)
        {
            trainSetFile = new File(args[0]);
        }
        if(args.length > 1)
        {
            testSetFile = new File(args[1]);
        }
        if(args.length > 2)
        {
            k = Integer.parseInt(args[2]);
        }
    }
}
