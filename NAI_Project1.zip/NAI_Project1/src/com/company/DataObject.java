package com.company;

import java.util.*;

// This class is just a structure for holding a vector and expectedOutput and output

public class DataObject
{
    private String type;
    private Vector4 data;
    private Map<Float,DataObject> distanceMap = new TreeMap<Float, DataObject>();  // treemap automatically sorts objects depending on their distance

    public DataObject(Vector4 data, String name)
    {
        this.data = data;
        type = name;
    }

    public DataObject(Vector4 data, List<DataObject> trainSetList)
    {
        this.data = data;
        CalculateDistance(trainSetList);
    }

    private void CalculateDistance(List<DataObject> trainSetList)  // it calculates the distance of all other objects from the
                                                                    // TrainSet and puts them into distanceMap
    {
        for (int i = 0; i < trainSetList.size(); i++)
        {
            distanceMap.put(trainSetList.get(i).GetVector4().GetDistance(this.GetVector4()),trainSetList.get(i));
        }
    }

    public void ClassifyObject(int k)                               // it checks K nearest objects from the distanceMap and counts
    {                                                               // most common type, then depending on which type is most common
                                                                    // in classifies the object.
        Iterator<Map.Entry<Float,DataObject>> iterator = distanceMap.entrySet().iterator();
        Map<String, Integer> counter = new HashMap<>();

        for (int i = 0; i < k && iterator.hasNext(); i++)
        {
            Map.Entry<Float,DataObject> entry = iterator.next();
            counter.put(entry.getValue().type, counter.get(entry.getValue().type) == null ? 0 : counter.get(entry.getValue().type) + 1);
            type = counter.entrySet().stream().max(((o1, o2) -> Integer.compare(o1.getValue(),o2.getValue()))).get().getKey();
        }
    }

    public Vector4 GetVector4()
    {
        return data;
    }

    @Override
    public String toString()
    {
        return type + " | " + data;
    }

    public String GetType()
    {
        return type;
    }
}
