package com.company;

import java.util.ArrayList;
import java.util.List;

public class Vector4
{
    public List<Float> values = new ArrayList<>();

    public Vector4(List<Float> values)
    {
        this.values = values;
    }

    // calculates the euclidean distance between this vector and the target vector
    public float GetDistance(Vector4 target)
    {
        float result =0;
        for (int i = 0; i < values.size(); i++)
        {
            result += ((float) Math.pow((values.get(i) - target.values.get(i)),2));
        }
        result = (float)Math.sqrt(result);

        return result;
    }

    @Override
    public String toString()
    {
        return values.toString();
    }
}

// vector that hold the values.Also this class had some math related methods which are used in perceptron