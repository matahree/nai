package com.company;

public record DataObject(String type, Vector values)
{

}
